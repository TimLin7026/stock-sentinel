#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
🛰️ 💰 鈔能戰情室 ── 特戰反快取型開機預載更新跳板 (多頁面原生自癒安全封裝版)
⚖️ 2026 Sentinel Tech. All rights reserved.
"""
import os
import sys

# 解決 Windows 主控台列印 Emoji 造成的 CP950 編碼出錯
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

import re
import json
import warnings
import streamlit as st
import requests
import urllib3
import hashlib
import uuid
import datetime

warnings.filterwarnings("ignore")
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PYC_ARMOR_PATH = os.path.join(BASE_DIR, "Stock_Sentinel_Launcher.pyc")
LOCAL_VERSION_FILE = os.path.join(BASE_DIR, "version_v2.txt")
# 確保 static 目錄存在以消滅 Uvicorn 警告並支援快照功能
os.makedirs(os.path.join(BASE_DIR, "static"), exist_ok=True)

# 🎯 動態字節碼自動對齊定錨與自癒 (必須在開機最前段執行，確保 import sentinel_db 不會壞 Magic)
def align_bytecode_version():
    py_ver = f"{sys.version_info.major}{sys.version_info.minor}"  # 例如 "313" 或 "314"
    import shutil
    
    # ❶ 根目錄的核心大腦對齊自癒
    modules = ["Stock_Sentinel_Launcher", "sentinel_db", "db_migration"]
    for mod in modules:
        specific_pyc = os.path.join(BASE_DIR, f"{mod}_{py_ver}.pyc")
        target_pyc = os.path.join(BASE_DIR, f"{mod}.pyc")
        if os.path.exists(specific_pyc):
            try:
                shutil.copy2(specific_pyc, target_pyc)
                print(f"[對齊自癒] 成功將 {mod}_{py_ver}.pyc 套用至 {mod}.pyc")
            except Exception as copy_err:
                print(f"[對齊失敗] 無法將 {mod}_{py_ver}.pyc 套用至 {mod}.pyc: {copy_err}")
                
    # ❷ 🧪 pages/ 目錄下的多版本對齊自癒與跳板重建
    pages_dir = os.path.join(BASE_DIR, "pages")
    if os.path.exists(pages_dir):
        # 尋找所有 _Launcher.pyc 變體並對齊
        for file in os.listdir(pages_dir):
            if file.endswith(f"_Launcher_{py_ver}.pyc"):
                base_launcher_name = file.replace(f"_{py_ver}.pyc", ".pyc")
                specific_page_pyc = os.path.join(pages_dir, file)
                target_page_pyc = os.path.join(pages_dir, base_launcher_name)
                try:
                    shutil.copy2(specific_page_pyc, target_page_pyc)
                    print(f"[對齊自癒] 成功還原 pages/{base_launcher_name}")
                except Exception as page_copy_err:
                    print(f"[對齊失敗] pages/{base_launcher_name} 還原失敗: {page_copy_err}")

        # ❸ 重建 pages/*.py 影子跳板 (防止跳板被使用者刪除)
        for file in os.listdir(pages_dir):
            if file.endswith("_Launcher.pyc"):
                base_name = file[:-4]  # 移除 .pyc
                launcher_py_name = f"{base_name}.py"
                launcher_py_path = os.path.join(pages_dir, launcher_py_name)
                if not os.path.exists(launcher_py_path):
                    if "1_" in file:
                        title = "策略選股中心"
                        icon = "🔍"
                    elif "2_" in file:
                        title = "社群情報站"
                        icon = "📡"
                    else:
                        title = base_name.replace("_Launcher", "")
                        icon = "📄"
                    
                    launcher_code = f"""# -*- coding: utf-8 -*-
import streamlit as st
import os
import sys
import marshal

# 🎯 對齊 Streamlit 原生導航標題與 Icon，確保黑盒子版側邊欄呈現美觀
st.set_page_config(page_title="{title}", page_icon="{icon}", layout="wide")

# 鎖定當前檔案所在的實體目錄，安全加載 pyc 字節碼大腦
current_dir = os.path.dirname(os.path.abspath(__file__))
target_pyc = os.path.join(current_dir, "{base_name}.pyc")

if os.path.exists(target_pyc):
    with open(target_pyc, "rb") as f:
        f.seek(16)
        bytecode_object = marshal.load(f)
    exec(bytecode_object, globals())
else:
    st.error(f"❌ 錯誤：找不到子頁面大腦核心 {base_name}.pyc")
"""
                    try:
                        with open(launcher_py_path, "w", encoding="utf-8") as lf:
                            lf.write(launcher_code)
                        print(f"[自癒重組] 成功重建影子跳板: {launcher_py_name}")
                    except Exception as gen_err:
                        print(f"[自癒失敗] 無法重建跳板 {launcher_py_name}: {gen_err}")

# ❹ 主大腦影子跳板重建自癒 (防止 Stock_Sentinel_Launcher.py 被誤刪)
def check_and_heal_main_launcher():
    main_launcher_py = os.path.join(BASE_DIR, "Stock_Sentinel_Launcher.py")
    if not os.path.exists(main_launcher_py):
        main_launcher_code = """# -*- coding: utf-8 -*-
import streamlit as st
import os
import sys
import marshal

# 🎯 對齊 Streamlit 原生導航標題與 Icon，確保黑盒子版主頁面呈現美觀
st.set_page_config(page_title="智能煉金雷達", page_icon="🏠", layout="wide")

current_dir = os.path.dirname(os.path.abspath(__file__))
target_pyc = os.path.join(current_dir, "Stock_Sentinel_Launcher.pyc")

if os.path.exists(target_pyc):
    with open(target_pyc, "rb") as f:
        f.seek(16)
        bytecode_object = marshal.load(f)
    exec(bytecode_object, globals())
else:
    st.error("❌ 錯誤：找不到鈔能雷達核心大腦 Stock_Sentinel_Launcher.pyc")
"""
        try:
            with open(main_launcher_py, "w", encoding="utf-8") as mf:
                mf.write(main_launcher_code)
            print("[自癒重組] 成功重建主大腦影子跳板: Stock_Sentinel_Launcher.py")
        except Exception as gen_err:
            print(f"[自癒失敗] 無法重建主大腦影子跳板: {gen_err}")

# 🚀 開機最先手對齊與自癒
align_bytecode_version()
check_and_heal_main_launcher()

# 🚀 授權檢測已封裝移入二進位加密 sentinel_db 模組中，明碼不再洩漏演算法與 SECRET_SALT
def check_is_license_valid():
    try:
        import sentinel_db
        db_path = os.path.join(BASE_DIR, "sentinel_vault.db")
        if not os.path.exists(db_path):
            parent_db = os.path.join(os.path.dirname(BASE_DIR), "sentinel_vault.db")
            if os.path.exists(parent_db):
                db_path = parent_db
        return sentinel_db.verify_license_keys(db_path)
    except Exception as check_err:
        print(f"⚠️ [授權檢測異常] {check_err}")
        return False

def parse_version_tuple(v_str):
    match = re.search(r"v?([\d\.]+)", v_str)
    if match:
        try:
            return tuple(int(x) for x in match.group(1).split(".") if x.isdigit())
        except:
            pass
    return (0,)

@st.cache_resource(show_spinner=False)
def is_local_bytecode_compatible():
    if not os.path.exists(PYC_ARMOR_PATH):
        return False
    try:
        import importlib.util
        with open(PYC_ARMOR_PATH, "rb") as f:
            local_magic = f.read(4)
        return local_magic[:2] == importlib.util.MAGIC_NUMBER[:2]
    except:
        return False

def bootstrap_core_update():
    """
    雙軌原子級聯動更新器 ── 先核對微型文字檔，通過後一併下載雙資產，100% 免疫二進位死鎖！
    支援跨 Python 版本自動識別並拉取相容的字節碼更新包。
    """
    if not check_is_license_valid():
        print("⚠️ [授權攔截] 當前本機裝置未偵測到合法時空授權金鑰，已跳過雲端升級比對。")
        return False

    py_ver = f"{sys.version_info.major}_{sys.version_info.minor}"  # 例如 "3_14"
    
    DEFAULT_GD_URLS = {
        "3_11": {
            "script": "https://timlin7026.github.io/stock-sentinel/鈔能雷達v2.zip",
            "version": "https://timlin7026.github.io/stock-sentinel/version_v2.txt"
        },
        "3_12": {
            "script": "https://timlin7026.github.io/stock-sentinel/鈔能雷達v2.zip",
            "version": "https://timlin7026.github.io/stock-sentinel/version_v2.txt"
        },
        "3_13": {
            "script": "https://timlin7026.github.io/stock-sentinel/鈔能雷達v2.zip",
            "version": "https://timlin7026.github.io/stock-sentinel/version_v2.txt"
        },
        "3_14": {
            "script": "https://timlin7026.github.io/stock-sentinel/鈔能雷達v2.zip",
            "version": "https://timlin7026.github.io/stock-sentinel/version_v2.txt"
        }
    }
    
    ver_urls = DEFAULT_GD_URLS.get(py_ver, DEFAULT_GD_URLS.get("3_13"))
    script_url = ver_urls["script"]
    version_url = ver_urls["version"]
    
    db_path = os.path.join(BASE_DIR, "sentinel_vault.db")
    if not os.path.exists(db_path):
        parent_db_path = os.path.join(os.path.dirname(BASE_DIR), "sentinel_vault.db")
        if os.path.exists(parent_db_path):
            db_path = parent_db_path

    if os.path.exists(db_path):
        import sqlite3
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM update_config")
            rows = cursor.fetchall()
            db_cfg = {row[0]: row[1] for row in rows}
            conn.close()
            
            specific_script_key = f"script_url_{py_ver}"
            specific_version_key = f"version_url_{py_ver}"
            
            if specific_script_key in db_cfg and db_cfg[specific_script_key].strip():
                script_url = db_cfg[specific_script_key].strip()
            elif "script_url" in db_cfg and db_cfg["script_url"].strip():
                script_url = db_cfg["script_url"].strip()
                
            if specific_version_key in db_cfg and db_cfg[specific_version_key].strip():
                version_url = db_cfg[specific_version_key].strip()
            elif "version_url" in db_cfg and db_cfg["version_url"].strip():
                version_url = db_cfg["version_url"].strip()
        except Exception as e:
            print(f"⚠️ [預載提示] 讀取資料庫配置失敗，將使用預設設定。原因: {e}")

    def extract_gdrive_id(url):
        match_path = re.search(r"/file/d/([a-zA-Z0-9_-]+)", url)
        if match_path:
            return match_path.group(1)
        match_query = re.search(r"[?&]id=([a-zA-Z0-9_-]+)", url)
        if match_query:
            return match_query.group(1)
        return None

    # 🌟 自動相容：若非 GDrive 網址（如 GitHub Pages），直接使用原網址；若是 GDrive 則轉換為直連
    if "drive.google.com" in script_url:
        script_id = extract_gdrive_id(script_url)
        if not script_id:
            print("⚠️ [預載提示] 雲端更新網址格式不正確，跳過版更檢查。")
            return False
        url_script_dl = f"https://drive.google.com/uc?export=download&id={script_id}"
    else:
        url_script_dl = script_url

    if "drive.google.com" in version_url:
        version_id = extract_gdrive_id(version_url)
        if not version_id:
            print("⚠️ [預載提示] 雲端更新網址格式不正確，跳過版更檢查。")
            return False
        url_version_dl = f"https://drive.google.com/uc?export=download&id={version_id}"
    else:
        url_version_dl = version_url
    browser_headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

    current_version_str = "v0.0"
    if os.path.exists(LOCAL_VERSION_FILE):
        try:
            with open(LOCAL_VERSION_FILE, 'r', encoding='utf-8') as f_v:
                current_version_str = f_v.read().strip()
        except: pass

    bytecode_ok = is_local_bytecode_compatible()
    if not bytecode_ok:
        print("⚠️ [相容性告警] 檢測到本地字節碼與當前 Python 版本不相容，將強制觸發自癒修復下載。")

    print(f"📡 [雙軌雷達] 本地現役版本線: {current_version_str} | 正在聯絡雲端大腦... (更新網址: {url_version_dl})")
    try:
        res_v = requests.get(url_version_dl, headers=browser_headers, timeout=10.0, verify=False)
        if res_v.status_code != 200: 
            print(f"❌ [雙軌雷達] 雲端連線失敗，HTTP 狀態碼: {res_v.status_code}")
            return False
            
        online_version_str = res_v.text.strip()
        online_val = parse_version_tuple(online_version_str)
        current_val = parse_version_tuple(current_version_str)

        if (online_val > current_val) or not bytecode_ok:
            if not bytecode_ok:
                print(f"📥 [版本自癒] 正在強制下載符合當前 Python 環境（{sys.version.split()[0]}）的字節碼程式包... (下載網址: {url_script_dl})")
            else:
                print(f"📥 [核准演進] 偵測到雲端全新升級壓縮包 (雲端 {online_version_str} > 本地 {current_version_str}) (下載網址: {url_script_dl})")
            
            print("⏳ 正在原子級同步下載 [升級壓縮包] 與 [版號標籤檔]...")
            res_full_zip = requests.get(url_script_dl, headers=browser_headers, timeout=60, verify=False)
            res_full_ver = requests.get(url_version_dl, headers=browser_headers, timeout=10, verify=False)
            
            if res_full_zip.status_code == 200 and len(res_full_zip.content) > 10000 and res_full_ver.status_code == 200:
                temp_zip_path = os.path.join(BASE_DIR, "temp_update.zip")
                with open(temp_zip_path, "wb") as f_zip:
                    f_zip.write(res_full_zip.content)
                
                import zipfile
                try:
                    with zipfile.ZipFile(temp_zip_path, 'r') as zip_ref:
                        zip_ref.extractall(BASE_DIR)
                    print("✨ [自動解壓] 所有字節碼與啟動腳本已覆蓋升級成功！")
                except Exception as unzip_err:
                    print(f"❌ [解壓失敗] 無法解開更新包，原因: {unzip_err}")
                    if os.path.exists(temp_zip_path):
                        os.remove(temp_zip_path)
                    return False
                
                if os.path.exists(temp_zip_path):
                    os.remove(temp_zip_path)
                
                with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f_ver:
                    f_ver.write(res_full_ver.text.strip())
                
                print(f"✨ 🌟 [大獲全勝] 看盤中樞已完美自動同步升級至 {online_version_str}！")
                return True
        else:
            print(f"🟢 [安全定錨] 當前版本 ({current_version_str}) 已對齊最高防禦線且字節碼相容，免除版更。")
    except Exception as e:
        print(f"⚠️ [預載提示] 雲端網絡超時，已切換至離線常規防禦。原因: {e}")
    return False

def get_compiled_python_version():
    if not os.path.exists(PYC_ARMOR_PATH):
        return "未知版本"
    try:
        with open(PYC_ARMOR_PATH, "rb") as f:
            magic_bytes = f.read(4)
        if len(magic_bytes) < 2:
            return "未知版本"
        import struct
        magic_val = struct.unpack('<H', magic_bytes[:2])[0]
        if 3600 <= magic_val < 3650:
            return "Python 3.14"
        elif 3550 <= magic_val < 3600:
            return "Python 3.13"
        elif 3500 <= magic_val < 3550:
            return "Python 3.12"
        elif 3450 <= magic_val < 3500:
            return "Python 3.11"
        elif 3430 <= magic_val < 3450:
            return "Python 3.10"
        elif 3420 <= magic_val < 3430:
            return "Python 3.9"
        elif 3390 <= magic_val < 3420:
            return "Python 3.8"
        else:
            return f"Python (代碼: {magic_val})"
    except:
        return "未知版本"

# 🚀 執行預載版更
bootstrap_core_update()

try:
    # 🚀 直接引導進入主導航，將控制權與金鑰審計提示完整交還給主程式大腦
    pg_main = st.Page("Stock_Sentinel_Launcher.py", title="智能煉金雷達", icon="🏠", default=True)
    pg_test = st.Page("pages/1_測試附屬頁_Launcher.py", title="策略選股中心", icon="🔍")
    pg_social = st.Page("pages/2_社群情報站_Launcher.py", title="社群情報站", icon="📡")
    
    pg = st.navigation([pg_main, pg_test, pg_social], position="sidebar")
    pg.run()
        
except Exception as e:
    if "bad magic number" in str(e):
        compiled_ver = get_compiled_python_version()
        st.error("❌ **[環境版本衝突] 偵測到 Python 執行版本與黑盒子字節碼不相容！**")
        st.markdown(f"""
        ### ⚠️ 啟動中止：Python 版本不相容
        * 💻 **目前執行環境**：`{sys.version.split()[0]}`
        * 📦 **程式包編譯版本**：`{compiled_ver}` (與當前環境不相容)
        
        ---
        
        ### 💡 解決方案與處理步驟：
        
        #### 1️⃣ 使用相容的 Python 版本（最快速）
        建議下載並安裝與此黑盒子程式包一致的 **`{compiled_ver}`**：
        * 👉 [前往 Python 官方下載頁面](https://www.python.org/downloads/) (請點擊 "Downloads" 並下載對應版本)
        
        #### 2️⃣ 更新黑盒子程式包
        如果您擁有合法的時空授權金鑰，請確保資料庫 `sentinel_vault.db` 配置正確。
        當授權成功通過，本啟動器會自動連線雲端大腦，拉取並更新與您當前 Python 版本相容的字節碼檔案。
        
        #### 3️⃣ 聯絡技術團隊手動更新
        若依然無法解決，請聯繫開發團隊，要求提供適用於您當前 Python 環境（`{sys.version.split()[0]}`）的 **`鈔能雷達v2.zip`** 專屬編譯包。
        """)
        st.stop()
    else:
        raise e