# -*- coding: utf-8 -*-
import streamlit as st
import os
import sys
import marshal

# 🎯 對齊 Streamlit 原生導航標題與 Icon，確保黑盒子版主頁面呈現美觀
st.set_page_config(page_title="智能煉金雷達", page_icon="🏠", layout="wide")

current_dir = os.path.dirname(os.path.abspath(__file__))
target_pyc = os.path.join(current_dir, "Stock_Sentinel_Launcher.pyc")

if os.path.exists(target_pyc):
    with open(target_pyc, "rb") as f:
        # 跳過 Python 3.7+ 的 16 位元組 .pyc Header，還原二進位字節碼為 code 物件
        f.seek(16)
        bytecode_object = marshal.load(f)
    exec(bytecode_object, globals())
else:
    st.error("❌ 錯誤：找不到鈔能雷達核心大腦 Stock_Sentinel_Launcher.pyc")
