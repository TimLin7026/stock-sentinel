# -*- coding: utf-8 -*-

import streamlit as st

import os

import sys

import marshal



# 🎯 對齊 Streamlit 原生導航標題與 Icon，確保黑盒子版側邊欄呈現美觀

st.set_page_config(page_title="社群情報站", page_icon="📡", layout="wide")



# 鎖定當前檔案所在的實體目錄，安全加載 pyc 字節碼大腦

current_dir = os.path.dirname(os.path.abspath(__file__))

target_pyc = os.path.join(current_dir, "2_社群情報站_Launcher.pyc")



if os.path.exists(target_pyc):

    with open(target_pyc, "rb") as f:

        # 跳過 Python 3.7+ 的 16 位元組 .pyc Header，還原二進位字節碼為 code 物件

        f.seek(16)

        bytecode_object = marshal.load(f)

    exec(bytecode_object, globals())

else:

    st.error(f"❌ 錯誤：找不到子頁面大腦核心 2_社群情報站_Launcher.pyc")

